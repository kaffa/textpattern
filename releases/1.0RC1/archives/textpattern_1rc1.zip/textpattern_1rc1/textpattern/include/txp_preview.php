<?php
include 'publish.php';

textpattern();

?>
